"use client"

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadialBarChart,
  RadialBar,
  Legend
} from "recharts"

const growthData = [
  { day: "Mon", growth: 12, optimal: 15 },
  { day: "Tue", growth: 18, optimal: 15 },
  { day: "Wed", growth: 15, optimal: 15 },
  { day: "Thu", growth: 22, optimal: 15 },
  { day: "Fri", growth: 19, optimal: 15 },
  { day: "Sat", growth: 25, optimal: 15 },
  { day: "Sun", growth: 28, optimal: 15 }
]

const waterUsageData = [
  { name: "Rack 1", usage: 45, saved: 15 },
  { name: "Rack 2", usage: 52, saved: 18 },
  { name: "Rack 3", usage: 38, saved: 12 },
  { name: "Rack 4", usage: 48, saved: 16 },
  { name: "Rack 5", usage: 42, saved: 14 }
]

const nutrientData = [
  { name: "Nitrogen", value: 85, fill: "oklch(0.8 0.25 140)" },
  { name: "Phosphorus", value: 72, fill: "oklch(0.75 0.2 195)" },
  { name: "Potassium", value: 90, fill: "oklch(0.65 0.2 250)" },
  { name: "Calcium", value: 68, fill: "oklch(0.8 0.15 85)" }
]

const energyData = [
  { month: "Jan", energy: 120, yield: 85 },
  { month: "Feb", energy: 115, yield: 88 },
  { month: "Mar", energy: 108, yield: 92 },
  { month: "Apr", energy: 95, yield: 95 },
  { month: "May", energy: 88, yield: 98 },
  { month: "Jun", energy: 82, yield: 102 }
]

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string }) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card rounded-lg p-3 border border-border/50">
        <p className="text-sm font-medium text-foreground mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-xs" style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export function AnalyticsCharts() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Plant Growth Over Time */}
      <div className="glass-card rounded-2xl p-6">
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-foreground">Plant Growth Trend</h3>
          <p className="text-xs text-muted-foreground">Daily growth rate vs optimal</p>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={growthData}>
              <defs>
                <linearGradient id="growthGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.8 0.25 140)" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="oklch(0.8 0.25 140)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 220)" />
              <XAxis dataKey="day" tick={{ fill: "oklch(0.6 0.01 180)", fontSize: 11 }} axisLine={false} />
              <YAxis tick={{ fill: "oklch(0.6 0.01 180)", fontSize: 11 }} axisLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="optimal"
                stroke="oklch(0.5 0.01 180)"
                strokeDasharray="5 5"
                strokeWidth={2}
                dot={false}
              />
              <Area
                type="monotone"
                dataKey="growth"
                stroke="oklch(0.8 0.25 140)"
                strokeWidth={2}
                fill="url(#growthGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Water Usage Efficiency */}
      <div className="glass-card rounded-2xl p-6">
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-foreground">Water Usage Efficiency</h3>
          <p className="text-xs text-muted-foreground">Usage vs water saved per rack</p>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={waterUsageData} barGap={8}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 220)" />
              <XAxis dataKey="name" tick={{ fill: "oklch(0.6 0.01 180)", fontSize: 11 }} axisLine={false} />
              <YAxis tick={{ fill: "oklch(0.6 0.01 180)", fontSize: 11 }} axisLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="usage" fill="oklch(0.75 0.2 195)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="saved" fill="oklch(0.8 0.25 140)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Nutrient Balance */}
      <div className="glass-card rounded-2xl p-6">
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-foreground">Nutrient Balance</h3>
          <p className="text-xs text-muted-foreground">Current nutrient levels</p>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="90%" data={nutrientData}>
              <RadialBar
                background={{ fill: "oklch(0.15 0.015 220)" }}
                dataKey="value"
                cornerRadius={4}
              />
              <Legend
                iconSize={8}
                layout="horizontal"
                verticalAlign="bottom"
                wrapperStyle={{ fontSize: "10px", color: "oklch(0.6 0.01 180)" }}
              />
              <Tooltip content={<CustomTooltip />} />
            </RadialBarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Energy vs Yield */}
      <div className="glass-card rounded-2xl p-6">
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-foreground">Energy vs Yield</h3>
          <p className="text-xs text-muted-foreground">Efficiency optimization over time</p>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={energyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 220)" />
              <XAxis dataKey="month" tick={{ fill: "oklch(0.6 0.01 180)", fontSize: 11 }} axisLine={false} />
              <YAxis tick={{ fill: "oklch(0.6 0.01 180)", fontSize: 11 }} axisLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="energy"
                stroke="oklch(0.65 0.2 250)"
                strokeWidth={2}
                dot={{ fill: "oklch(0.65 0.2 250)", r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="yield"
                stroke="oklch(0.8 0.25 140)"
                strokeWidth={2}
                dot={{ fill: "oklch(0.8 0.25 140)", r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
