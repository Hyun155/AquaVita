"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Leaf,
  Droplets,
  Fish,
  Sun,
  Bug,
  Recycle,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight
} from "lucide-react"

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard Overview", active: true },
  { icon: Leaf, label: "Plant Health AI" },
  { icon: Droplets, label: "Water & Nutrient System" },
  { icon: Fish, label: "Aquaponics Loop" },
  { icon: Sun, label: "Climate & UV Control" },
  { icon: Bug, label: "Pest & Algae Defense" },
  { icon: Recycle, label: "Waste-to-Fertilizer AI" },
  { icon: BarChart3, label: "Analytics & History" },
  { icon: Settings, label: "Settings" }
]

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside
      className={cn(
        "h-screen glass-card border-r border-border/50 flex flex-col transition-all duration-300 sticky top-0",
        collapsed ? "w-20" : "w-64"
      )}
    >
      <div className="p-4 flex items-center justify-between border-b border-border/30">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-neon-green to-neon-aqua flex items-center justify-center">
              <Leaf className="w-5 h-5 text-background" />
            </div>
            <span className="font-semibold text-sm gradient-text">AgriNexus</span>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-lg hover:bg-secondary/50 transition-colors text-muted-foreground hover:text-foreground"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {menuItems.map((item, index) => (
          <button
            key={index}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group",
              item.active
                ? "bg-gradient-to-r from-neon-green/20 to-neon-aqua/10 text-neon-green neon-green-glow"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            )}
          >
            <item.icon
              className={cn(
                "w-5 h-5 shrink-0 transition-transform group-hover:scale-110",
                item.active && "animate-pulse-glow"
              )}
            />
            {!collapsed && (
              <span className="text-sm font-medium truncate">{item.label}</span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-border/30">
        {!collapsed && (
          <div className="glass-card rounded-xl p-3 bg-gradient-to-br from-neon-green/10 to-neon-blue/5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
              <span className="text-xs text-muted-foreground">System Status</span>
            </div>
            <p className="text-sm font-medium text-success">All Systems Online</p>
          </div>
        )}
      </div>
    </aside>
  )
}
