"use client"

import { Sprout, Droplets, Zap, Recycle } from "lucide-react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Navbar } from "@/components/dashboard/navbar"
import { KPICard } from "@/components/dashboard/kpi-card"
import { DigitalTwin } from "@/components/dashboard/digital-twin"
import { AIAdvisor } from "@/components/dashboard/ai-advisor"
import { AlertsPanel } from "@/components/dashboard/alerts-panel"
import { AnalyticsCharts } from "@/components/dashboard/analytics-charts"
import { SustainabilityPanel } from "@/components/dashboard/sustainability-panel"

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        <Navbar />
        
        <div className="flex-1 p-6 space-y-6">
          {/* KPI Cards */}
          <section>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <KPICard
                title="Plant Health Score"
                value={87}
                icon={<Sprout className="w-5 h-5" />}
                trend={4.2}
                color="green"
              />
              <KPICard
                title="Water Quality Score"
                value={92}
                icon={<Droplets className="w-5 h-5" />}
                trend={2.1}
                color="aqua"
                unit=""
              />
              <KPICard
                title="Energy Efficiency"
                value={78}
                icon={<Zap className="w-5 h-5" />}
                trend={-1.5}
                color="yellow"
                unit="%"
              />
              <KPICard
                title="Sustainability Index"
                value={85}
                icon={<Recycle className="w-5 h-5" />}
                trend={6.8}
                color="blue"
              />
            </div>
          </section>

          {/* Digital Twin & AI Advisor */}
          <section className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <div className="xl:col-span-2">
              <DigitalTwin />
            </div>
            <div>
              <AIAdvisor />
            </div>
          </section>

          {/* Alerts Panel */}
          <section>
            <AlertsPanel />
          </section>

          {/* Analytics Section */}
          <section>
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-foreground">Analytics & Insights</h2>
              <p className="text-sm text-muted-foreground">Performance metrics and trends</p>
            </div>
            <AnalyticsCharts />
          </section>

          {/* Sustainability Module */}
          <section>
            <SustainabilityPanel />
          </section>

          {/* Footer */}
          <footer className="text-center py-6 border-t border-border/30">
            <p className="text-sm text-muted-foreground">
              <span className="gradient-text font-semibold">AgriNexus HydroAI+</span> • Hybrid Smart Hydroponic-Aquaponic Intelligence System
            </p>
            <p className="text-xs text-muted-foreground/60 mt-1">
              Powered by IoT Sensors • AI Plant Vision • Smart Automation
            </p>
          </footer>
        </div>
      </main>
    </div>
  )
}
